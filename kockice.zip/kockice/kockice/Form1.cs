namespace kockice
{
    public partial class Form1 : Form
    {
        List<Button> dodatni = new List<Button>();
        int brojtastera = 30;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.PerformClick();
            button3.Focus();
            timer1.Start();
        }

        private void button3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button3.Left -= 30;
            if (e.KeyChar == 's') button3.Top += 30;
            if (e.KeyChar == 'd') button3.Left += 30;
            if (e.KeyChar == 'w') button3.Top -= 30;
            if (button2.Left < 0) button2.Left = 0;
            if (button2.Top < 0) button2.Top = 0;
            if (button2.Left > 480) button2.Left = 480;
            if (button2.Top > 330) button2.Top = 330;
            for (int i = dodatni.Count - 1; i >= 0; i--)
            {
                if (button3.Bounds.IntersectsWith(dodatni[i].Bounds))
                {

                    dodatni[i].Dispose();
                    dodatni.RemoveAt(i);
                    int poeni = Convert.ToInt16(label1.Text);
                    poeni++;
                    label1.Text = Convert.ToString(poeni);
                }
            }
            if (dodatni.Count == 0) button2.PerformClick();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random broj = new Random();
            brojtastera++;
            for (int i = 0; i < brojtastera; i++)
            {
                Button taster = new Button();
                panel2.Controls.Add(taster);
                int x = broj.Next(0, panel2.Width / 30) * 30;
                if (x == 8) x--;

                int y = broj.Next(0, panel2.Height / 30) * 30;
                if (y == 6) y--;

                taster.Location = new Point(x, y);

                taster.Size = new Size(30, 30);
                taster.BackColor = Color.DarkRed;
                dodatni.Add(taster);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button4.Top += 7;
            if (button4.Top > 330) button4.Top = 0;


            if (button4.Bounds.IntersectsWith(button3.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
