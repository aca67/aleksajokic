namespace brickbreaker
{
    public partial class Form1 : Form
    {
        int pomy = 2;
        int pomx = 2;
        int pomy2 = 2;
        int pomx2 = 2;
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Focus();
            timer1.Start();
            label2.Text = "0";
            button25.Left = 380;
            button25.Top = 231;
            button24.Top = 231;
            button24.Left = 157;
            button2.Top = 503;
            button2.Left = 210;

            button3.Left = 22;
            button3.Top = 6;
            button6.Left = 100;
            button6.Top = 6;
            button5.Left = 179;
            button5.Top = 6;
            button4.Left = 253;
            button4.Top = 6;
            button7.Left = 333;
            button7.Top = 6;
            button8.Left = 414;
            button8.Top = 6;
            button9.Left = 499;
            button9.Top = 6;

            button10.Left = 22;
            button10.Top = 77;
            button11.Left = 100;
            button11.Top = 77;
            button12.Left = 179;
            button12.Top =77;
            button13.Left = 253;
            button13.Top = 77;
            button14.Left = 333;
            button14.Top = 77;
            button15.Left = 414;
            button15.Top = 77;
            button16.Left = 499;
            button16.Top = 77;

            button17.Left = 22;
            button17.Top = 153;
            button18.Left = 100;
            button18.Top = 153;
            button19.Left = 179;
            button19.Top = 153;
            button20.Left = 253;
            button20.Top = 153;
            button21.Left = 333;
            button21.Top = 153;
            button22.Left = 414;
            button22.Top = 153;
            button23.Left = 499;
            button23.Top = 153;





        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int poeni = Convert.ToInt16(label2.Text);

            button25.Top += pomy;
            button25.Left += pomx;
            if (button25.Top < 0) pomy = (-1) * pomy;
            if (button25.Left < 0) pomx = (-1) * pomx;
            if (button25.Left > 540) pomx = (-1) * pomx;
            if (button25.Top > 514)
            {
                timer1.Stop();
                button25.Left = 380;
                button25.Top = 231;
                button24.Top = 231;
                button24.Left = 157;
                MessageBox.Show("GAME OVER \n Ostvaren broj poena:" + poeni);
                timer1.Stop();
            }
            if (button25.Bounds.IntersectsWith(button2.Bounds))
            {
                pomy = (-1) * pomy;
            }




            button24.Top += pomy2;
            button24.Left += pomx2;
            if (button24.Top < 0) pomy2 = (-1) * pomy2;
            if (button24.Left < 0) pomx2 = (-1) * pomx2;
            if (button24.Left > 540) pomx2 = (-1) * pomx2;
            if (button24.Top > 514)
            {
                timer1.Stop();
                button24.Top = 231;
                button24.Left = 157;
                button25.Left = 380;
                button25.Top = 231;
                MessageBox.Show("GAME OVER \n Ostvaren broj poena:" + poeni);
                timer1.Stop();
            }
            if (button24.Bounds.IntersectsWith(button2.Bounds))
            {
                pomy2 = (-1) * pomy2;
            }


            if (button24.Bounds.IntersectsWith(button3.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button3.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button4.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button4.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button5.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button5.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button6.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button6.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button7.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button7.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button8.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button8.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button9.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button9.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button10.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button10.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button11.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button11.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button12.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button12.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button13.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button13.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button14.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button14.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button15.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button15.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button16.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button16.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button17.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button17.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button18.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button18.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button19.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button19.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button20.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button20.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button21.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button21.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button22.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button22.Top = -50000;
                poeni++;
            }
            if (button24.Bounds.IntersectsWith(button23.Bounds))
            {
                pomy2 = (-1) * pomy2;
                button23.Top = -50000;
                poeni++;
            }




            if (button25.Bounds.IntersectsWith(button3.Bounds))
            {
                pomy = (-1) * pomy;
                button3.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button4.Bounds))
            {
                pomy = (-1) * pomy;
                button4.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button5.Bounds))
            {
                pomy = (-1) * pomy;
                pomy = (-1) * pomy;
                button5.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button6.Bounds))
            {
                pomy = (-1) * pomy;
                button6.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button7.Bounds))
            {
                pomy = (-1) * pomy;
                button7.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button8.Bounds))
            {
                pomy = (-1) * pomy;
                button8.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button9.Bounds))
            {
                pomy = (-1) * pomy;
                button9.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button10.Bounds))
            {
                pomy = (-1) * pomy;
                button10.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button11.Bounds))
            {
                pomy = (-1) * pomy;
                button11.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button12.Bounds))
            {
                pomy = (-1) * pomy;
                button12.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button13.Bounds))
            {
                pomy = (-1) * pomy;
                button13.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button14.Bounds))
            {
                pomy = (-1) * pomy;
                button14.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button15.Bounds))
            {
                pomy = (-1) * pomy;
                button15.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button16.Bounds))
            {
                pomy = (-1) * pomy;
                button16.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button17.Bounds))
            {
                pomy = (-1) * pomy;
                button17.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button18.Bounds))
            {
                pomy = (-1) * pomy;
                button18.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button19.Bounds))
            {
                pomy = (-1) * pomy;
                button19.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button20.Bounds))
            {
                pomy = (-1) * pomy;
                button20.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button21.Bounds))
            {
                pomy = (-1) * pomy;
                button21.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button22.Bounds))
            {
                pomy = (-1) * pomy;
                button22.Top = -50000;
                poeni++;
            }
            if (button25.Bounds.IntersectsWith(button23.Bounds))
            {
                pomy = (-1) * pomy;
                button23.Top = -50000;
                poeni++;
            }
            label2.Text = Convert.ToString(poeni);

            if (poeni > 20)
            {
                MessageBox.Show("YOU WON \n Osvojeni broj poena je" + poeni);
                timer1.Stop();
            }

            label2.Text = Convert.ToString(poeni);


        }

        private void button25_Click(object sender, EventArgs e)
        {

        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button2.Left -= 7;
            
            if(e.KeyChar == 'd') button2.Left += 7;
            

            if (button2.Left<0) button2.Left = 0;
            if (button2.Left >428) button2.Left = 428;

        }
    }
}
