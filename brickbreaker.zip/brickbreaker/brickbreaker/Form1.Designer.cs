﻿namespace brickbreaker
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            label2 = new Label();
            label1 = new Label();
            button1 = new Button();
            panel2 = new Panel();
            button25 = new Button();
            button24 = new Button();
            button23 = new Button();
            button22 = new Button();
            button21 = new Button();
            button20 = new Button();
            button19 = new Button();
            button18 = new Button();
            button17 = new Button();
            button16 = new Button();
            button15 = new Button();
            button14 = new Button();
            button13 = new Button();
            button12 = new Button();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.PeachPuff;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(570, 104);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Showcard Gothic", 19.8000011F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Olive;
            label2.Location = new Point(420, 29);
            label2.Name = "label2";
            label2.Size = new Size(39, 43);
            label2.TabIndex = 2;
            label2.Text = "0";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Showcard Gothic", 19.8000011F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(128, 64, 64);
            label1.Location = new Point(276, 29);
            label1.Name = "label1";
            label1.Size = new Size(120, 43);
            label1.TabIndex = 1;
            label1.Text = "POENI";
            // 
            // button1
            // 
            button1.BackColor = Color.LightCoral;
            button1.Font = new Font("Showcard Gothic", 15F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.FromArgb(64, 0, 0);
            button1.Location = new Point(42, 29);
            button1.Name = "button1";
            button1.Size = new Size(116, 51);
            button1.TabIndex = 0;
            button1.Text = "START";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.PapayaWhip;
            panel2.Controls.Add(button25);
            panel2.Controls.Add(button24);
            panel2.Controls.Add(button23);
            panel2.Controls.Add(button22);
            panel2.Controls.Add(button21);
            panel2.Controls.Add(button20);
            panel2.Controls.Add(button19);
            panel2.Controls.Add(button18);
            panel2.Controls.Add(button17);
            panel2.Controls.Add(button16);
            panel2.Controls.Add(button15);
            panel2.Controls.Add(button14);
            panel2.Controls.Add(button13);
            panel2.Controls.Add(button12);
            panel2.Controls.Add(button11);
            panel2.Controls.Add(button10);
            panel2.Controls.Add(button9);
            panel2.Controls.Add(button8);
            panel2.Controls.Add(button7);
            panel2.Controls.Add(button6);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 104);
            panel2.Name = "panel2";
            panel2.Size = new Size(570, 544);
            panel2.TabIndex = 1;
            // 
            // button25
            // 
            button25.BackgroundImage = (Image)resources.GetObject("button25.BackgroundImage");
            button25.BackgroundImageLayout = ImageLayout.Stretch;
            button25.Location = new Point(380, 231);
            button25.Name = "button25";
            button25.Size = new Size(30, 30);
            button25.TabIndex = 23;
            button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            button24.BackgroundImage = (Image)resources.GetObject("button24.BackgroundImage");
            button24.BackgroundImageLayout = ImageLayout.Stretch;
            button24.Location = new Point(157, 231);
            button24.Name = "button24";
            button24.Size = new Size(30, 30);
            button24.TabIndex = 22;
            button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            button23.BackColor = Color.Firebrick;
            button23.Location = new Point(499, 153);
            button23.Name = "button23";
            button23.Size = new Size(45, 45);
            button23.TabIndex = 21;
            button23.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            button22.BackColor = Color.Firebrick;
            button22.Location = new Point(414, 153);
            button22.Name = "button22";
            button22.Size = new Size(45, 45);
            button22.TabIndex = 20;
            button22.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            button21.BackColor = Color.Firebrick;
            button21.Location = new Point(333, 153);
            button21.Name = "button21";
            button21.Size = new Size(45, 45);
            button21.TabIndex = 19;
            button21.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            button20.BackColor = Color.Firebrick;
            button20.Location = new Point(253, 153);
            button20.Name = "button20";
            button20.Size = new Size(45, 45);
            button20.TabIndex = 18;
            button20.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            button19.BackColor = Color.Firebrick;
            button19.Location = new Point(179, 153);
            button19.Name = "button19";
            button19.Size = new Size(45, 45);
            button19.TabIndex = 17;
            button19.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            button18.BackColor = Color.Firebrick;
            button18.Location = new Point(100, 153);
            button18.Name = "button18";
            button18.Size = new Size(45, 45);
            button18.TabIndex = 16;
            button18.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            button17.BackColor = Color.Firebrick;
            button17.Location = new Point(22, 153);
            button17.Name = "button17";
            button17.Size = new Size(45, 45);
            button17.TabIndex = 15;
            button17.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            button16.BackColor = Color.Firebrick;
            button16.Location = new Point(499, 77);
            button16.Name = "button16";
            button16.Size = new Size(45, 45);
            button16.TabIndex = 14;
            button16.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            button15.BackColor = Color.Firebrick;
            button15.Location = new Point(414, 77);
            button15.Name = "button15";
            button15.Size = new Size(45, 45);
            button15.TabIndex = 13;
            button15.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            button14.BackColor = Color.Firebrick;
            button14.Location = new Point(333, 77);
            button14.Name = "button14";
            button14.Size = new Size(45, 45);
            button14.TabIndex = 12;
            button14.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            button13.BackColor = Color.Firebrick;
            button13.Location = new Point(253, 77);
            button13.Name = "button13";
            button13.Size = new Size(45, 45);
            button13.TabIndex = 11;
            button13.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            button12.BackColor = Color.Firebrick;
            button12.Location = new Point(179, 77);
            button12.Name = "button12";
            button12.Size = new Size(45, 45);
            button12.TabIndex = 10;
            button12.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            button11.BackColor = Color.Firebrick;
            button11.Location = new Point(100, 77);
            button11.Name = "button11";
            button11.Size = new Size(45, 45);
            button11.TabIndex = 9;
            button11.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            button10.BackColor = Color.Firebrick;
            button10.Location = new Point(22, 77);
            button10.Name = "button10";
            button10.Size = new Size(45, 45);
            button10.TabIndex = 8;
            button10.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = Color.Firebrick;
            button9.Location = new Point(499, 6);
            button9.Name = "button9";
            button9.Size = new Size(45, 45);
            button9.TabIndex = 7;
            button9.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            button8.BackColor = Color.Firebrick;
            button8.Location = new Point(414, 6);
            button8.Name = "button8";
            button8.Size = new Size(45, 45);
            button8.TabIndex = 6;
            button8.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.Firebrick;
            button7.Location = new Point(333, 6);
            button7.Name = "button7";
            button7.Size = new Size(45, 45);
            button7.TabIndex = 5;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Firebrick;
            button6.Location = new Point(100, 6);
            button6.Name = "button6";
            button6.Size = new Size(45, 45);
            button6.TabIndex = 4;
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.Firebrick;
            button5.Location = new Point(179, 6);
            button5.Name = "button5";
            button5.Size = new Size(45, 45);
            button5.TabIndex = 3;
            button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.Firebrick;
            button4.Location = new Point(253, 6);
            button4.Name = "button4";
            button4.Size = new Size(45, 45);
            button4.TabIndex = 2;
            button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Firebrick;
            button3.Location = new Point(22, 6);
            button3.Name = "button3";
            button3.Size = new Size(45, 45);
            button3.TabIndex = 1;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.RosyBrown;
            button2.Location = new Point(210, 503);
            button2.Name = "button2";
            button2.Size = new Size(142, 29);
            button2.TabIndex = 0;
            button2.UseVisualStyleBackColor = false;
            button2.KeyPress += button2_KeyPress;
            // 
            // timer1
            // 
            timer1.Interval = 1;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(570, 648);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button button1;
        private Panel panel2;
        private Label label2;
        private Label label1;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button23;
        private Button button22;
        private Button button21;
        private Button button20;
        private Button button19;
        private Button button18;
        private Button button17;
        private Button button16;
        private Button button15;
        private Button button14;
        private Button button13;
        private Button button12;
        private Button button11;
        private Button button10;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button24;
        private Button button25;
        private System.Windows.Forms.Timer timer1;
    }
}
