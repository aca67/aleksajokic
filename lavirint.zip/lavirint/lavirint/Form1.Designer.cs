﻿namespace lavirint
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            label2 = new Label();
            label4 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 0, 0);
            button1.Location = new Point(12, 76);
            button1.Name = "button1";
            button1.Size = new Size(30, 30);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = false;
            button1.KeyPress += button1_KeyPress;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ControlDarkDark;
            button2.Location = new Point(0, 41);
            button2.Name = "button2";
            button2.Size = new Size(876, 29);
            button2.TabIndex = 1;
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ControlDarkDark;
            button3.Location = new Point(0, 123);
            button3.Name = "button3";
            button3.Size = new Size(773, 29);
            button3.TabIndex = 2;
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ControlDarkDark;
            button4.Location = new Point(874, 41);
            button4.Name = "button4";
            button4.Size = new Size(33, 180);
            button4.TabIndex = 3;
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.ControlDarkDark;
            button5.Location = new Point(740, 123);
            button5.Name = "button5";
            button5.Size = new Size(33, 163);
            button5.TabIndex = 4;
            button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.ControlDarkDark;
            button6.Location = new Point(740, 281);
            button6.Name = "button6";
            button6.Size = new Size(446, 29);
            button6.TabIndex = 5;
            button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.ControlDarkDark;
            button7.Location = new Point(874, 192);
            button7.Name = "button7";
            button7.Size = new Size(495, 29);
            button7.TabIndex = 6;
            button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.ControlDarkDark;
            button8.Location = new Point(461, 304);
            button8.Name = "button8";
            button8.Size = new Size(29, 91);
            button8.TabIndex = 7;
            button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.ControlDarkDark;
            button9.Location = new Point(633, 366);
            button9.Name = "button9";
            button9.Size = new Size(736, 29);
            button9.TabIndex = 8;
            button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.ControlDarkDark;
            button10.Location = new Point(614, 217);
            button10.Name = "button10";
            button10.Size = new Size(31, 358);
            button10.TabIndex = 9;
            button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.ControlDarkDark;
            button11.Location = new Point(152, 217);
            button11.Name = "button11";
            button11.Size = new Size(493, 29);
            button11.TabIndex = 10;
            button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            button12.BackColor = SystemColors.ControlDarkDark;
            button12.Location = new Point(0, 292);
            button12.Name = "button12";
            button12.Size = new Size(490, 29);
            button12.TabIndex = 11;
            button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            button13.BackColor = SystemColors.ControlDarkDark;
            button13.Location = new Point(352, 453);
            button13.Name = "button13";
            button13.Size = new Size(293, 29);
            button13.TabIndex = 12;
            button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            button14.BackColor = SystemColors.ControlDarkDark;
            button14.Location = new Point(352, 374);
            button14.Name = "button14";
            button14.Size = new Size(32, 108);
            button14.TabIndex = 13;
            button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            button15.BackColor = SystemColors.ControlDarkDark;
            button15.Location = new Point(103, 375);
            button15.Name = "button15";
            button15.Size = new Size(283, 29);
            button15.TabIndex = 14;
            button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            button16.BackColor = SystemColors.ControlDarkDark;
            button16.Location = new Point(0, 453);
            button16.Name = "button16";
            button16.Size = new Size(251, 29);
            button16.TabIndex = 15;
            button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            button17.BackColor = SystemColors.ControlDarkDark;
            button17.Location = new Point(614, 651);
            button17.Name = "button17";
            button17.Size = new Size(31, 99);
            button17.TabIndex = 16;
            button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            button18.BackColor = Color.Magenta;
            button18.Location = new Point(481, 488);
            button18.Name = "button18";
            button18.Size = new Size(25, 25);
            button18.TabIndex = 17;
            button18.Text = "x";
            button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            button19.BackColor = Color.Magenta;
            button19.Location = new Point(821, 412);
            button19.Name = "button19";
            button19.Size = new Size(25, 25);
            button19.TabIndex = 18;
            button19.Text = "x";
            button19.UseVisualStyleBackColor = false;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.BackColor = Color.Magenta;
            button20.Location = new Point(984, 699);
            button20.Name = "button20";
            button20.Size = new Size(25, 25);
            button20.TabIndex = 19;
            button20.Text = "x";
            button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            button21.BackColor = Color.Magenta;
            button21.Location = new Point(1109, 412);
            button21.Name = "button21";
            button21.Size = new Size(25, 25);
            button21.TabIndex = 20;
            button21.Text = "x";
            button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            button22.BackgroundImage = (Image)resources.GetObject("button22.BackgroundImage");
            button22.BackgroundImageLayout = ImageLayout.Stretch;
            button22.Location = new Point(1267, 513);
            button22.Name = "button22";
            button22.Size = new Size(90, 90);
            button22.TabIndex = 21;
            button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            button23.BackColor = SystemColors.ActiveCaption;
            button23.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            button23.Location = new Point(1181, 57);
            button23.Name = "button23";
            button23.Size = new Size(176, 62);
            button23.TabIndex = 22;
            button23.Text = "START";
            button23.UseVisualStyleBackColor = false;
            button23.Click += button23_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label2.Location = new Point(960, 57);
            label2.Name = "label2";
            label2.Size = new Size(98, 35);
            label2.TabIndex = 24;
            label2.Text = "VREME";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            label4.Location = new Point(974, 92);
            label4.Name = "label4";
            label4.Size = new Size(60, 46);
            label4.TabIndex = 26;
            label4.Text = "50";
            label4.Click += label4_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Interval = 1000;
            timer2.Tick += timer2_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1369, 736);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(button23);
            Controls.Add(button22);
            Controls.Add(button21);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Label label2;
        private Label label4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}
