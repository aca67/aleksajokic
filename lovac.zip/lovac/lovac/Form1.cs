namespace lovac
{
    public partial class Form1 : Form
    {
        int pomeraj = 5;
        int nadji = 3;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
            button2.Enabled = true;
            button2.Focus();
            label1.Text = "0";

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random x = new Random();
            int smer = x.Next(4);
            if (smer == 0) button3.Left += pomeraj;
            if (smer == 1) button3.Top += pomeraj;
            if (smer == 2) button3.Left -= pomeraj;
            if (smer == 3) button3.Top -= pomeraj;

            smer = x.Next(4);
            if (smer == 0) button4.Left += pomeraj;
            if (smer == 1) button4.Top += pomeraj;
            if (smer == 2) button4.Left -= pomeraj;
            if (smer == 3) button4.Top -= pomeraj;

            smer = x.Next(4);
            if (smer == 0) button6.Left += pomeraj;
            if (smer == 1) button6.Top += pomeraj;
            if (smer == 2) button6.Left -= pomeraj;
            if (smer == 3) button6.Top -= pomeraj;

            smer = x.Next(4);
            if (smer == 0) button7.Left += pomeraj;
            if (smer == 1) button7.Top += pomeraj;
            if (smer == 2) button7.Left -= pomeraj;
            if (smer == 3) button7.Top -= pomeraj;

            if (button2.Left < button3.Left) button3.Left -= nadji;
            if (button2.Top < button3.Top) button3.Top -= nadji;
            if (button2.Left > button3.Left) button3.Left += nadji;
            if (button2.Top > button3.Top) button3.Top += nadji;


            if (button2.Left < button4.Left) button4.Left -= nadji;
            if (button2.Top < button4.Top) button4.Top -= nadji;
            if (button2.Left > button4.Left) button4.Left += nadji;
            if (button2.Top > button4.Top) button4.Top += nadji;

            if (button2.Left < button6.Left) button6.Left -= nadji;
            if (button2.Top < button6.Top) button6.Top -= nadji;
            if (button2.Left > button6.Left) button6.Left += nadji;
            if (button2.Top > button6.Top) button6.Top += nadji;

            if (button2.Left < button7.Left) button7.Left -= nadji;
            if (button2.Top < button7.Top) button7.Top -= nadji;
            if (button2.Left > button7.Left) button7.Left += nadji;
            if (button2.Top > button7.Top) button7.Top += nadji;

            if (button3.Left < 0) button3.Left = 0;
            if (button3.Top < 0) button3.Top = 0;
            if (button3.Left > 1311) button3.Left = 1311;
            if (button3.Top > 608) button3.Top = 608;

            if (button4.Left < 0) button4.Left = 0;
            if (button4.Top < 0) button4.Top = 0;
            if (button4.Left > 1311) button4.Left = 1311;
            if (button4.Top > 608) button4.Top = 608;

            if (button6.Left < 0) button6.Left = 0;
            if (button6.Top < 0) button6.Top = 0;
            if (button6.Left > 1311) button6.Left = 1311;
            if (button6.Top > 608) button6.Top = 608;

            if (button7.Left < 0) button7.Left = 0;
            if (button7.Top < 0) button7.Top = 0;
            if (button7.Left > 1311) button7.Left = 1311;
            if (button7.Top > 608) button7.Top = 608;

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Random x = new Random();
            button5.Left = x.Next(1335);
            button5.Top = x.Next(649);
            if (button5.Left < 0) button5.Left = 0;
            if (button5.Top < 0) button5.Top = 0;
            if (button5.Left > 1311) button5.Left = 1311;
            if (button5.Top > 608) button5.Top = 608;
        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button2.Left -= 10;
            if (e.KeyChar == 's') button2.Top += 10;
            if (e.KeyChar == 'd') button2.Left += 10;
            if (e.KeyChar == 'w') button2.Top -= 10;

            if (button2.Left < 0) button2.Left = 0;
            if (button2.Top < 0) button2.Top = 0;
            if (button2.Left > 1311) button2.Left = 1311;
            if (button2.Top > 608) button2.Top = 608;

            int poeni = Convert.ToInt32(label1.Text);
            if (button2.Bounds.IntersectsWith(button5.Bounds))
                {
                poeni++;
                Random x = new Random();
                button5.Left = x.Next(1335);
                button5.Top = x.Next(649);
            }
            label1.Text = Convert.ToString(poeni);

            if (button2.Bounds.IntersectsWith(button3.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }

            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }

            if (button2.Bounds.IntersectsWith(button6.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }

            if (button2.Bounds.IntersectsWith(button7.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }


        }
    }
}
