namespace flappybird
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button3.Left -= 5;
            button4.Left -= 5;
            button5.Left -= 5;
            button6.Left -= 5;
            button7.Left -= 5;
            button8.Left -= 5;
            int poeni = Convert.ToInt16(label2.Text);

            Random x = new Random();
            if (button3.Left < -12)
            {
                button3.Left = 1031;
                button4.Left = 1031;
                int vel = x.Next(300);
                button3.Height = vel;
                button4.Height = (410 - (vel + 80));
                button4.Top = vel + 80;
                poeni++;

            }

            if (button5.Left < -12)
            {
                button5.Left = 1031;
                button6.Left = 1031;
                int vel = x.Next(300);
                button5.Height = vel;
                button6.Height = (410 - (vel + 80));
                button6.Top = vel + 80;
                poeni++;

            }

            if (button7.Left < -12)
            {
                button7.Left = 1031;
                button8.Left = 1031;
                int vel = x.Next(300);
                button7.Height = vel;
                button8.Height = (410 - (vel + 80));
                button8.Top = vel + 80;
                poeni++;

            }

            label2.Text = Convert.ToString(poeni);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            label2.Text = "0";
            button2.Left = 12;
            button2.Top = 175;
            button3.Left = 229;
            button4.Left = 229;
            button5.Left = 538;
            button6.Left = 538;
            button7.Left = 812;
            button8.Left = 812;
            button2.Focus();
            
        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button2.Left -= 5;
            if (e.KeyChar == 's') button2.Top += 5;
            if (e.KeyChar == 'd') button2.Left += 5;
            if (e.KeyChar == 'w') button2.Top -= 5;

            if (button2.Left < 0) button2.Left = 0;
            if (button2.Left > 1001) button2.Left = 1001;
            if (button2.Top < 0) button2.Top = 0;
            if (button2.Top > 361) button2.Top = 361;

            if (button2.Bounds.IntersectsWith(button3.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button5.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button6.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button7.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button8.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
        }
    }
}
